===========
Payzippy SDK
===========

Payzippy SDK which provides the interface to interacts with the Papzippy APIs for charging, query and refund using Python scripting

For the complete usage and examples, please refer the examples given in the SDK

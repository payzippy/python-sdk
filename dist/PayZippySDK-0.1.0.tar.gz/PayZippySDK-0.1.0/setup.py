from distutils.core import setup

setup(
    name='PayZippySDK',
    version='0.1.0',
    author='Lustre Japang',
    author_email='lustre.japang@flipkart.com',
    packages=['payzippysdk'],
    url='https://www.payzippy.com/developers',
    license='LICENSE.txt',
    description='PayZippy SDK for Python.',
    long_description=open('README.txt').read(),
    install_requires=[
        "Python >= 2.5.6",
    ],
)